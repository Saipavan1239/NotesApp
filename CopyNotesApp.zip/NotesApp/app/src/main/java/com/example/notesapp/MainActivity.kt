package com.example.notesapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.notesapp.Database.NotesDatabase
import com.example.notesapp.Repository.NoteRepository
import com.example.notesapp.ViewModel.NoteViewModel
import com.example.notesapp.ViewModel.NoteViewModelFactory
import com.example.notesapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private val binding : ActivityMainBinding by lazy{
        ActivityMainBinding.inflate(layoutInflater)
    }

    lateinit var noteViewModel: NoteViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setUpViewModel()
    }

    private fun setUpViewModel(){
        val noteRepository = NoteRepository(NotesDatabase(this))
        val viewModelProviderFactory = NoteViewModelFactory(application , noteRepository)
        noteViewModel = ViewModelProvider(this, viewModelProviderFactory)[NoteViewModel::class.java]
    }
}